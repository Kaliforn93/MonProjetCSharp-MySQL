using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using System.Windows;
using LiveChartsCore;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore.SkiaSharpView.WPF;
using MySql.Data.MySqlClient;
using System.Linq;

namespace ProjetWPF_MySQL_Final
{
    public partial class MainWindow : Window
    {
        private string connectionString = "server=localhost;userid=root;password=;database=ems_l1";

        public MainWindow()
        {
            InitializeComponent();
            LoadColumnList();
        }

        private void LoadColumnList()
        {
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var cmd = new MySqlCommand("SHOW COLUMNS FROM line_1_temperature_humidity", conn);
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    var col = reader["Field"].ToString();
                    if (col != "timestamp")
                        ColumnSelector.Items.Add(col);
                }
                conn.Close();
            }
        }

        private void LoadData_Click(object sender, RoutedEventArgs e)
        {
            DateTime start = StartDatePicker.SelectedDate ?? DateTime.Now.AddDays(-1);
            DateTime end = EndDatePicker.SelectedDate ?? DateTime.Now;
            double seuilHaut = double.TryParse(SeuilHautBox.Text, out var sh) ? sh : double.NaN;
            double seuilBas = double.TryParse(SeuilBasBox.Text, out var sb) ? sb : double.NaN;

            var selectedCols = ColumnSelector.SelectedItems.Cast<string>().ToList();
            if (!selectedCols.Any()) return;

            var series = new List<ISeries>();
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var colList = string.Join(",", selectedCols.Select(c => $"`{c}`"));
                var query = $"SELECT timestamp, {colList} FROM line_1_temperature_humidity WHERE timestamp BETWEEN '{start:yyyy-MM-dd}' AND '{end:yyyy-MM-dd}' ORDER BY timestamp ASC LIMIT 1000";
                var cmd = new MySqlCommand(query, conn);
                var reader = cmd.ExecuteReader();

                var timeList = new List<DateTime>();
                var valueLists = selectedCols.ToDictionary(col => col, col => new List<double?>());

                while (reader.Read())
                {
                    timeList.Add(Convert.ToDateTime(reader["timestamp"]));
                    foreach (var col in selectedCols)
                    {
                        valueLists[col].Add(reader[col] == DBNull.Value ? null : Convert.ToDouble(reader[col]));
                    }
                }

                foreach (var col in selectedCols)
                {
                    series.Add(new LineSeries<double?>
                    {
                        Values = valueLists[col],
                        Name = col,
                        GeometrySize = 0
                    });
                }

                SensorChart.Series = series;
                SensorChart.XAxes = new Axis[] { new Axis { Labels = timeList.Select(t => t.ToString("dd/MM HH:mm")).ToArray(), LabelsRotation = 45 } };
                SensorChart.YAxes = new Axis[] {
                    new Axis {
                        Sections = new List<AxisSection> {
                            new AxisSection { Value = seuilHaut, Label = $"Seuil Haut: {seuilHaut}" },
                            new AxisSection { Value = seuilBas, Label = $"Seuil Bas: {seuilBas}" }
                        }
                    }
                };

                conn.Close();
            }
        }

        private void ExportCSV_Click(object sender, RoutedEventArgs e)
        {
            var sb = new StringBuilder();
            var selectedCols = ColumnSelector.SelectedItems.Cast<string>().ToList();
            sb.Append("timestamp," + string.Join(",", selectedCols) + "\n");
            File.WriteAllText("export_capteurs.csv", sb.ToString());
            MessageBox.Show("CSV exporté avec succès !");
        }
    }
}
